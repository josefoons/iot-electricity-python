<html>
	<head>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600' rel='stylesheet' type='text/css'>
		<link href="style/style.css" rel="stylesheet" charset=UTF-8>
		<title>ConfigWeb - TTU</title>
		<link rel="shortcut icon" href="/img/icon.ico" />
	</head>

	<body>
	<!-- Esto es el menu -->
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="ip.php">IP</a></li>
			<li><a href="datos.php">Data</a></li>
			<li><a href="https://github.com/josefoons/iot-electricity-python/blob/master/Downloads/Instructions.txt">TUTORIAL</a></li>
		</ul>
		
	<!-- Esto es el contenido de la web -->

	
		<div class="bigtext">
			<h1>Welcome</h1>
				<hr>
			<p id="hip">Welcome User to this web, which is dedicated to collect data of device to which it is connected. If you are having problems talk to the person in charge of carrying this.</a>
		
		</div>

	<!-- Esto es el copy -->
		<div class="copy">
			<a>©Created only for Tallinn University of Technology (TUT)</a>
		</div>

	</body>
</html>

